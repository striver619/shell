yum localinstall python2-jmespath-0.9.4-2.el7.noarch.rpm sshpass-1.06-2.el7.x86_64.rpm python-httplib2-0.9.2-1.el7.noarch.rpm -y
yum localinstall ansible-2.9.14-1.el7.noarch.rpm  -y
